package application;

import exceptions.InvalidAdminException;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import users.Admin;
import users.User;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Airline System");

        // Main login scene
        GridPane loginPane = new GridPane();
        loginPane.setAlignment(Pos.CENTER);
        loginPane.setVgap(10);
        loginPane.setHgap(10);

        Label welcomeLabel = new Label("Select Login Type");
        Button adminButton = new Button("Admin");
        Button passengerButton = new Button("Passenger");

        loginPane.add(welcomeLabel, 0, 0, 2, 1);
        loginPane.add(adminButton, 0, 1);
        loginPane.add(passengerButton, 1, 1);

        Scene loginScene = new Scene(loginPane, 300, 200);

        // Admin login scene
        GridPane adminPane = new GridPane();
        adminPane.setAlignment(Pos.CENTER);
        adminPane.setVgap(10);
        adminPane.setHgap(10);

        Label adminLabel = new Label("Admin Login");
        TextField userIdField = new TextField();
        PasswordField passwordField = new PasswordField();
        Button adminLoginButton = new Button("Login");
        Button adminBackButton = new Button("Back");
        
        adminPane.add(adminLabel, 0, 0, 2, 1);
        adminPane.add(new Label("User ID:"), 0, 1);
        adminPane.add(userIdField, 1, 1);
        adminPane.add(new Label("Password:"), 0, 2);
        adminPane.add(passwordField, 1, 2);
        adminPane.add(adminLoginButton, 0, 3);
        adminPane.add(adminBackButton, 1, 3);

        Scene adminScene = new Scene(adminPane, 300, 200);

        // Event handlers
        adminButton.setOnAction(e -> primaryStage.setScene(adminScene));
        
        passengerButton.setOnAction(e -> {
            User user = new User();
            user.displayMenu();  // Start a new User thread when Passenger button is clicked
            //primaryStage.close();  // Optionally close the main login window
        });

        adminBackButton.setOnAction(e -> primaryStage.setScene(loginScene));

        adminLoginButton.setOnAction(e -> {
            String userId = userIdField.getText();
            String password = passwordField.getText();
            Admin admin = new Admin();
            try {
				if (admin.verifyAdmin(userId, password)) {
				    Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
				    successAlert.setTitle("Login Successful");
				    successAlert.setHeaderText(null);
				    successAlert.setContentText("Welcome, Admin!");
				    successAlert.showAndWait();
				    Admin administrator = new Admin();
				    administrator.menu();
				    primaryStage.setScene(loginScene);
				    //primaryStage.close();
				} else {
				    Alert errorAlert = new Alert(Alert.AlertType.ERROR);
				    errorAlert.setTitle("Login Failed");
				    errorAlert.setHeaderText(null);
				    errorAlert.setContentText("Invalid User ID or Password.");
				    errorAlert.showAndWait();
				}
			} catch (InvalidAdminException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        });

        // Set the main login scene
        primaryStage.setScene(loginScene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
