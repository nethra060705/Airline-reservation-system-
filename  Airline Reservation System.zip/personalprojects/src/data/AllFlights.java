package data;


import java.time.LocalDate;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
import models.Flight;

public class AllFlights {
    public static List<Flight> flights = new ArrayList<>();    
    
    public static List<Flight> getFlightList() {
        return flights;
    }

    public static void displayFlightList() {
        flights.forEach(flight -> System.out.println(flight.getFlightDetails()));
    }

    public static void addFlight(Flight flight) {
        flights.add(flight);
    }

    public static void editFlight(int flightNo) {
        Optional<Flight> flightOptional = flights.stream()
                                                 .filter(f -> f.getFlightNo() == flightNo)
                                                 .findFirst();
        if (flightOptional.isPresent()) {
            Flight flight = flightOptional.get();
            @SuppressWarnings("resource")
			Scanner scanner = new Scanner(System.in);

            System.out.println("Editing details for Flight No: " + flightNo);

            System.out.print("Enter new flight name: ");
            flight.setFlightName(scanner.nextLine());

            System.out.print("Enter new departure date (YYYY-MM-DD): ");
            flight.setDepartureDate(LocalDate.parse(scanner.nextLine()));

            System.out.print("Enter new departure time (HH:MM): ");
            flight.setDepartureTime(LocalTime.parse(scanner.nextLine()));

            System.out.print("Enter new origin: ");
            flight.setOrigin(scanner.nextLine());

            System.out.print("Enter new destination: ");
            flight.setDestination(scanner.nextLine());

            System.out.print("Enter new total seats: ");
            flight.setTotalSeats(scanner.nextInt());

            System.out.println("Flight details updated successfully.");
        } else {
            System.out.println("Flight not found with Flight No: " + flightNo);
        }
    }
    public static void cancelFlight(int flightNo) {
        flights.removeIf(flight -> flight.getFlightNo() == flightNo);
    }

    public static Flight findFlightByNumber(int flightNo) {
        for (Flight flight : flights) {
            if (flight.getFlightNo() == flightNo) {
                return flight;
            }
        }
        return null;
    }
    
}
