package data;

import java.time.LocalDate;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import models.Flight;

public class InternationalFlights extends AllFlights{
	public static List<Flight> flights = new ArrayList<>();
	static {
    	addFlight(new Flight(10001, "Emirates", LocalDate.parse("2024-12-01"), LocalTime.of(19, 20), "ABU DHABI", "WASHINGTON"));
    	addFlight(new Flight(10002, "Emirates", LocalDate.parse("2024-12-05"), LocalTime.of(15, 30), "DELHI", "ABU DHABI"));
    	addFlight(new Flight(10003, "Qatar Airways", LocalDate.parse("2024-12-11"), LocalTime.of(7, 05), "MUMBAI", "QATAR"));
    	addFlight(new Flight(10004, "Singapore Airlines", LocalDate.parse("2025-01-17"), LocalTime.of(16, 25), "SINGAPORE", "MUMBAI"));
    	addFlight(new Flight(10005, "Qatar Airways", LocalDate.parse("2025-01-23"), LocalTime.of(22, 23), "QATAR", "MANGALURU"));
    }
	
	public static List<Flight> getFlightList() {
        return flights;
    }

    public static void displayFlightList() {
        flights.forEach(flight -> System.out.println(flight.getFlightDetails()));
    }

    public static void addFlight(Flight flight) {
        flights.add(flight);
    }

    public static void editFlight(int flightNo) {
        Optional<Flight> flightOptional = flights.stream()
                                                 .filter(f -> f.getFlightNo() == flightNo)
                                                 .findFirst();
        if (flightOptional.isPresent()) {
            Flight flight = flightOptional.get();
            @SuppressWarnings("resource")
			Scanner scanner = new Scanner(System.in);

            System.out.println("Editing details for Flight No: " + flightNo);

            System.out.print("Enter new departure date (YYYY-MM-DD): ");
            flight.setDepartureDate(LocalDate.parse(scanner.nextLine()));

            System.out.print("Enter new departure time (HH:MM): ");
            flight.setDepartureTime(LocalTime.parse(scanner.nextLine()));

            System.out.println("Flight details updated successfully.");
        } else {
            System.out.println("Flight not found with Flight No: " + flightNo);
        }
    }
    public static void cancelFlight(int flightNo) {
        flights.removeIf(flight -> flight.getFlightNo() == flightNo);
    }

    public static Flight findFlightByNumber(int flightNo) {
        for (Flight flight : flights) {
            if (flight.getFlightNo() == flightNo) {
                return flight;
            }
        }
        return null;
    }
}
