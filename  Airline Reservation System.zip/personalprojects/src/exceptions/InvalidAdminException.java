package exceptions;

@SuppressWarnings("serial")
public class InvalidAdminException extends Exception {
	public InvalidAdminException(String message)
	{
		super(message);
	}
}
