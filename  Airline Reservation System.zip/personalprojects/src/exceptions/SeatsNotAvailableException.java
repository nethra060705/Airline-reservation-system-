package exceptions;

@SuppressWarnings("serial")
public class SeatsNotAvailableException extends Exception {
    public SeatsNotAvailableException(String message) {
        super(message);
    }
}
