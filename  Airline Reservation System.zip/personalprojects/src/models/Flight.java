package models;

import java.time.LocalDate;

import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

public class Flight {
    private int flightNo;
    private String flightName;
    private LocalDate departureDate;
    private LocalTime departureTime;
    private String origin;
    private String destination;
    private int totalSeats = 240; // Default value
    private int availableSeats = 240; // Default value

    // Constructor to initialize flight details
    public Flight(int flightNo, String flightName, LocalDate departureDate, LocalTime departureTime, String origin, String destination) {
        this.flightNo = flightNo;
        this.flightName = flightName;
        this.departureDate = departureDate;
        this.departureTime = departureTime;
        this.origin = origin;
        this.destination = destination;
    }

    // Method to update available seats
    public void updateSeats(int seatsToBook) {
        if (seatsToBook > availableSeats) {
            System.out.println("Not enough seats available.");
        } else {
            availableSeats -= seatsToBook;
        }
    }

    // Method to get flight details as a formatted string
    public String getFlightDetails() {
        return "Flight No: " + flightNo + "\n" +
               "Flight Name: " + flightName + "\n" +
               "Departure Date: " + departureDate + "\n" +
               "Departure Time: " + departureTime + "\n" +
               "Origin: " + origin + "\n" +
               "Destination: " + destination + "\n" +
               "Total Seats: " + totalSeats + "\n" +
               "Available Seats: " + availableSeats + "\n";
    }

    // Method to calculate the current price based on the days until departure
    public double currentPrice() {
        long daysUntilDeparture = LocalDate.now().until(departureDate, ChronoUnit.DAYS);

        if (daysUntilDeparture <= 30) {
            return 10000;
        } else if (daysUntilDeparture <= 60) {
            return 9000;
        } else if (daysUntilDeparture <= 90) {
            return 8000;
        } else {
            return 6500;
        }
    }

    // Getter and Setter for availableSeats
    public int getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(int seats) {
        availableSeats = seats;
    }

    // Getter methods
    public int getFlightNo() {
        return flightNo;
    }

    public String getFlightName() {
        return flightName;
    }

    public LocalDate getDepartureDate() {
        return departureDate;
    }

    public LocalTime getDepartureTime() {
        return departureTime;
    }

    public String getOrigin() {
        return origin;
    }

    public String getDestination() {
        return destination;
    }

	public void setFlightName(String nextLine) {
		flightName = nextLine;
	}

	public void setDepartureTime(LocalTime localTime) {
		departureTime = localTime;
	}

	public void setDepartureDate(LocalDate localDate) {
		departureDate = localDate;
	}

	public void setOrigin(String nextLine) {
		origin = nextLine;
	}

	public void setTotalSeats(int nextInt) {
		totalSeats = nextInt;		
	}
	
	public int getTotalSeats()
	{
		return totalSeats;
	}
	
	public int getBookedSeats()
	{
		return totalSeats - availableSeats;
	}

	public void setDestination(String nextLine) {
		destination = nextLine;		
	}
	
	
}
