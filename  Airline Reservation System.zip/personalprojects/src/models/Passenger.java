package models;

public class Passenger {
    private String name;
    private int age;
    private long aadhar;
    private long contactNo;
    private Flight flightDetails;
    private double price;
    private int numberOfSeats;

    // Parameterized constructor
    public Passenger(String name, int age, long aadhar, long contactNo) {
        this.name = name;
        this.age = age;
        this.aadhar = aadhar;
        this.contactNo = contactNo;
        this.setPrice(setPrice()); // Sets price based on some logic
    }

    // Method to set price (can be customized as per requirements)
    private double setPrice() {
        // Implement logic to set price, for example:
        return age > 60 ? 1000.0 : 1500.0; // Sample logic for senior citizen discount
    }

    // Getter methods
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public long getAadhar() {
        return aadhar;
    }

    public long getContactNo() {
        return contactNo;
    }

    public Flight getFlightDetails() {
        return flightDetails;
    }

    // Method to set Flight details (if needed)
    public void setFlightDetails(Flight flightDetails) {
        this.flightDetails = flightDetails;
    }

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getNumberOfSeats() {
		return numberOfSeats;
	}

	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}
}
