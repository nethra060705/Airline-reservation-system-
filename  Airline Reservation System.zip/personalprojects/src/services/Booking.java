package services;

import models.Flight;
import models.Passenger;
import exceptions.*;
//import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;


public class Booking {
	private boolean isInternational;
	
	public Booking(boolean isInternational)
	{
		this.isInternational = isInternational;
	}
    // Method to check if seats are available
    public boolean checkSeats(Flight flight) throws SeatsNotAvailableException {
        if (flight.getAvailableSeats() > 0) {
            return true;
        } else {
            throw new SeatsNotAvailableException("No seats available on this flight.");
        }
    }

    // Method to get passenger info using JavaFX UI and update seats
    public void getInfo(Flight flight) throws InvalidEntryException {
        Stage stage = new Stage();
        stage.setTitle("Enter Passenger Details");

        // Creating form elements
        TextField nameField = new TextField();
        TextField ageField = new TextField();
        TextField aadharField = new TextField();
        TextField contactNoField = new TextField();
        TextField numberOfSeatsField = new TextField();
        Button submitButton = new Button("Submit");

        // Layout setup
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);

        // Adding elements to the grid
        grid.add(new Label("Name:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Age:"), 0, 1);
        grid.add(ageField, 1, 1);
        grid.add(new Label("Aadhar:"), 0, 2);
        grid.add(aadharField, 1, 2);
        grid.add(new Label("Contact No:"), 0, 3);
        grid.add(contactNoField, 1, 3);
        grid.add(new Label("Number of Seats:"), 0, 4);
        grid.add(numberOfSeatsField, 1, 4);
        grid.add(submitButton, 1, 5);

        // Setting up the scene
        Scene scene = new Scene(grid, 300, 250);
        stage.setScene(scene);
        stage.show();

        // Event handler for the submit button
        submitButton.setOnAction(e -> {
            try {
                String name = nameField.getText();
                int age = Integer.parseInt(ageField.getText());
                long aadhar = Long.parseLong(aadharField.getText());
                long contactNo = Long.parseLong(contactNoField.getText());
                int numberOfSeats = Integer.parseInt(numberOfSeatsField.getText());

                // Create Passenger object and set flight details
                Passenger passenger = new Passenger(name, age, aadhar, contactNo);
                passenger.setFlightDetails(flight);

                // Update seats in the Flight
                flight.updateSeats(numberOfSeats);
                passenger.setNumberOfSeats(numberOfSeats);
                stage.close();
                Invoice.printInvoice(passenger, flight, isInternational);
            } catch (NumberFormatException ex) {
                // Handle invalid entry in age, aadhar, or contactNo fields
                throw new InvalidEntryException("Please enter valid input for Age, Aadhar, and Contact No.");
            }
        });
    }

    // Method to book a ticket
    public void bookTicket(Flight flight) throws SeatsNotAvailableException, InvalidEntryException {
        if (checkSeats(flight)) {
            getInfo(flight); // Gather passenger info and update seats
        }
    }
}
