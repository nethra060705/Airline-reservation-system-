package services;

import javafx.application.Application;


import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import models.Flight;

import java.util.ArrayList;
import java.util.List;

import data.InternationalFlights;

public class InternationalFlightsReport extends Application {

	public InternationalFlightsReport()
	{
		start(new Stage());
	}
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Flight Statistics Report");

        // Sample data
        List<Flight> flights = InternationalFlights.getFlightList();

        // Create a GridPane layout
        GridPane gridPane = new GridPane();
        generateInternationalReport(gridPane, flights);

        // Create and set the scene
        Scene scene = new Scene(gridPane, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void generateInternationalReport(GridPane gridPane, List<Flight> flights) {
        Flight mostBookedFlight = null;
        String mostVisitedDestination = null;
        String mostFlownFrom = null;
        int maxBookings = 0, maxVisitedCount = 0, maxFlownFromCount = 0;
        
        List<Flight> completelyBookedFlights = new ArrayList<>();
        List<String> destinations = new ArrayList<>();
        List<String> origins = new ArrayList<>();

        // Calculate the statistics
        for (Flight flight : flights) {
            int bookings = flight.getTotalSeats() - flight.getAvailableSeats();
            if (bookings > maxBookings) {
                maxBookings = bookings;
                mostBookedFlight = flight;
            }

            // Track counts for each destination and origin
            destinations.add(flight.getDestination());
            origins.add(flight.getOrigin());

            if (flight.getAvailableSeats() == 0) {
                completelyBookedFlights.add(flight);
            }
        }

        // Find the most visited destination
        for (String destination : destinations) {
            int count = (int) destinations.stream().filter(d -> d.equals(destination)).count();
            if (count > maxVisitedCount) {
                maxVisitedCount = count;
                mostVisitedDestination = destination;
            }
        }

        // Find the most flown-from origin
        for (String origin : origins) {
            int count = (int) origins.stream().filter(o -> o.equals(origin)).count();
            if (count > maxFlownFromCount) {
                maxFlownFromCount = count;
                mostFlownFrom = origin;
            }
        }

        // Populate GridPane with statistics
        int row = 0;
        gridPane.add(new Label("Flight Statistics Report"), 0, row++, 2, 1);

        if (mostBookedFlight != null) {
            gridPane.add(new Label("Most Frequently Booked Flight: "), 0, row);
            gridPane.add(new Label(mostBookedFlight.getFlightName() + " (Flight No: " + mostBookedFlight.getFlightNo() + ")"), 1, row++);
        }

        if (mostVisitedDestination != null) {
            gridPane.add(new Label("Most Visited Destination: "), 0, row);
            gridPane.add(new Label(mostVisitedDestination), 1, row++);
        }

        if (mostFlownFrom != null) {
            gridPane.add(new Label("Most Flown-From Origin: "), 0, row);
            gridPane.add(new Label(mostFlownFrom), 1, row++);
        }

        if (!completelyBookedFlights.isEmpty()) {
            gridPane.add(new Label("Completely Booked Flights: "), 0, row++);
            for (Flight flight : completelyBookedFlights) {
                gridPane.add(new Label(flight.getFlightName() + " (Flight No: " + flight.getFlightNo() + ")"), 1, row++);
            }
        } else {
            gridPane.add(new Label("No flights are completely booked."), 0, row++);
        }
    }
}