package services;

import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import models.Flight;
import models.Passenger;

public class Invoice {
	
    // Method to print the invoice
    public static void printInvoice(Passenger passenger, Flight flight, boolean isInternational) {
        Stage stage = new Stage();
        stage.setTitle("Invoice");

        // Create labels to display passenger and flight details
        Label passengerDetails = new Label("Passenger Details:");
        Label nameLabel = new Label("Name: " + passenger.getName());
        Label ageLabel = new Label("Age: " + passenger.getAge());
        Label aadharLabel = new Label("Aadhar: " + passenger.getAadhar());
        Label contactNoLabel = new Label("Contact No: " + passenger.getContactNo());

        // Flight details
        Label flightDetails = new Label("Flight Details:");
        Label flightNoLabel = new Label("Flight No: " + flight.getFlightNo());
        Label flightNameLabel = new Label("Flight Name: " + flight.getFlightName());
        Label departureDateLabel = new Label("Departure Date: " + flight.getDepartureDate());
        Label departureTimeLabel = new Label("Departure Time: " + flight.getDepartureTime());
        Label originLabel = new Label("Origin: " + flight.getOrigin());
        Label destinationLabel = new Label("Destination: " + flight.getDestination());

        // Calculate the total amount
        double totalAmount = flight.currentPrice()*passenger.getNumberOfSeats()*(isInternational?1.5:1);

        // Create a label for the net amount
        Label amountLabel = new Label("Net Amount: Rs " + totalAmount);

        // Layout for the invoice
        VBox layout = new VBox(10);
        layout.getChildren().addAll(
            passengerDetails, nameLabel, ageLabel, aadharLabel, contactNoLabel,
            flightDetails, flightNoLabel, flightNameLabel, departureDateLabel,
            departureTimeLabel, originLabel, destinationLabel,
            amountLabel
        );

        // Create scene and set the stage
        Scene scene = new Scene(layout, 300, 400);
        stage.setScene(scene);
        stage.show();
    }
}
