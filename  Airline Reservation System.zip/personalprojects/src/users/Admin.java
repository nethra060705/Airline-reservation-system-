package users;

import java.time.LocalDate;

import java.time.LocalTime;
import services.*;
import data.*;
import exceptions.InvalidAdminException;
import exceptions.InvalidEntryException;
//import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import models.Flight;

public class Admin {
    // Mock credentials storage (username-password pairs)
    private String[][] userPassTup = {{"popcorn", "coke"}, {"chocolate", "brownie"},{"french", "fries"}, {"admin", "admin123"}};

    // Method to verify admin credentials
    public boolean verifyAdmin(String username, String password) throws InvalidAdminException {
        boolean valid = false;
        for (String[] credentials : userPassTup) {
            if (credentials[0].equals(username) && credentials[1].equals(password)) {
                valid = true;
                break;
            }
        }

        if (valid) {
            new Thread(this::menu).start(); // Start admin menu in a new thread
        } else {
            throw new InvalidAdminException("Invalid username or password.");
        }
        return valid;
    }

    // Main admin menu for managing flights
    public void menu() {
        Stage stage = new Stage();
        stage.setTitle("Admin Menu");

        Button viewInternationalFlightsButton = new Button("View International Flight Details");
        Button scheduleInternationalFlightButton = new Button("Schedule International Flight");
        Button rescheduleInternationalFlightButton = new Button("Reschedule International Flight");
        Button cancelInternationalFlightButton = new Button("Cancel International Flight");
        Button viewDomesticFlightsButton = new Button("View Domestic Flight Details");
        Button scheduleDomesticFlightButton = new Button("Schedule Domestic Flight");
        Button rescheduleDomesticFlightButton = new Button("Reschedule Domestic Flight");
        Button cancelDomesticFlightButton = new Button("Cancel Domestic Flight");
        Button generateDomesticReport = new Button("Domestic Report");
        Button generateInternationalReport = new Button("International Report");

        // Event handlers
        viewInternationalFlightsButton.setOnAction(e -> viewInternationalFlightDetails());
        scheduleInternationalFlightButton.setOnAction(e -> scheduleInternationalFlight());
        rescheduleInternationalFlightButton.setOnAction(e -> rescheduleInternationalFlight());
        cancelInternationalFlightButton.setOnAction(e -> cancelInternationalFlight());
        viewDomesticFlightsButton.setOnAction(e -> viewDomesticFlightDetails());
        scheduleDomesticFlightButton.setOnAction(e -> scheduleDomesticFlight());
        rescheduleDomesticFlightButton.setOnAction(e -> rescheduleDomesticFlight());
        cancelDomesticFlightButton.setOnAction(e -> cancelDomesticFlight());
        generateDomesticReport.setOnAction(e -> generateDomesticFilghtsReport());
        generateInternationalReport.setOnAction(e -> generateInternationalFilghtsReport());

        GridPane layout = new GridPane();
        layout.setPadding(new Insets(10));
        layout.setVgap(10);
        layout.add(viewInternationalFlightsButton, 0, 0);
        layout.add(scheduleInternationalFlightButton, 0, 1);
        layout.add(rescheduleInternationalFlightButton, 0, 2);
        layout.add(cancelInternationalFlightButton, 0, 3);
        layout.add(generateInternationalReport, 0, 4);
        layout.add(viewDomesticFlightsButton, 2, 0);
        layout.add(scheduleDomesticFlightButton, 2, 1);
        layout.add(rescheduleDomesticFlightButton, 2, 2);
        layout.add(cancelDomesticFlightButton, 2, 3);
        layout.add(generateDomesticReport, 2, 4);

        stage.setScene(new Scene(layout, 400, 200));
        stage.show();
    }

    // Displays all flight details in a new stage
    public void viewInternationalFlightDetails() {
        Stage stage = new Stage();
        stage.setTitle("Flight Details");

        TextArea flightDetails = new TextArea();
        flightDetails.setEditable(false);

        // Populate flight details
        StringBuilder details = new StringBuilder();
        for(Flight temp : InternationalFlights.flights)
        {
        	details.append(temp.getFlightDetails()).append("\n");
        }
        flightDetails.setText(details.toString());

        stage.setScene(new Scene(flightDetails, 400, 300));
        stage.show();
    }

    // Scene to create a new flight
    public void scheduleInternationalFlight() {
        Stage stage = new Stage();
        stage.setTitle("Schedule Flight");

        // Fields for flight details
        TextField flightNoField = new TextField();
        TextField flightNameField = new TextField();
        TextField departureDateField = new TextField();
        TextField departureTimeField = new TextField();
        TextField originField = new TextField();
        TextField destinationField = new TextField();

        Button submitButton = new Button("Add Flight");

        // Layout setup
        GridPane layout = new GridPane();
        layout.setPadding(new Insets(10));
        layout.setVgap(10);
        layout.add(new Label("Flight No:"), 0, 0);
        layout.add(flightNoField, 1, 0);
        layout.add(new Label("Flight Name:"), 0, 1);
        layout.add(flightNameField, 1, 1);
        layout.add(new Label("Departure Date (YYYY-MM-DD):"), 0, 2);
        layout.add(departureDateField, 1, 2);
        layout.add(new Label("Departure Time (HH:MM):"), 0, 3);
        layout.add(departureTimeField, 1, 3);
        layout.add(new Label("Origin:"), 0, 4);
        layout.add(originField, 1, 4);
        layout.add(new Label("Destination:"), 0, 5);
        layout.add(destinationField, 1, 5);
        layout.add(submitButton, 1, 6);

        submitButton.setOnAction(e -> {
            try {
                int flightNo = Integer.parseInt(flightNoField.getText());
                String flightName = flightNameField.getText();
                LocalDate departureDate = LocalDate.parse(departureDateField.getText());
                LocalTime departureTime = LocalTime.parse(departureTimeField.getText());
                String origin = originField.getText();
                String destination = destinationField.getText();

                Flight flight = new Flight(flightNo, flightName, departureDate, departureTime, origin, destination);
                InternationalFlights.addFlight(flight);
                stage.close();
                System.out.println("Flight scheduled successfully.");
            } catch (Exception ex) {
                System.out.println("Invalid input. Please enter valid details.");
            }
        });

        stage.setScene(new Scene(layout, 400, 300));
        stage.show();
    }

    // Scene to reschedule an existing flight
    public void rescheduleInternationalFlight() {
        Stage stage = new Stage();
        stage.setTitle("Reschedule Flight");

        TextField flightNoField = new TextField();
        TextField newTimeField = new TextField();
        Button submitButton = new Button("Reschedule");

        GridPane layout = new GridPane();
        layout.setPadding(new Insets(10));
        layout.setVgap(10);
        layout.add(new Label("Flight No:"), 0, 0);
        layout.add(flightNoField, 1, 0);
        layout.add(new Label("New Departure Time (HH:MM):"), 0, 1);
        layout.add(newTimeField, 1, 1);
        layout.add(submitButton, 1, 2);

        submitButton.setOnAction(e -> {
            try {
                int flightNo = Integer.parseInt(flightNoField.getText());
                @SuppressWarnings("unused")
				LocalTime newTime = LocalTime.parse(newTimeField.getText());

                InternationalFlights.editFlight(flightNo); // Call method to edit flight time
                stage.close();
                System.out.println("Flight rescheduled successfully.");
            } catch (NumberFormatException ex) {
                throw new InvalidEntryException("Invalid flight number or time format.");
            }
        });

        stage.setScene(new Scene(layout, 300, 200));
        stage.show();
    }

    // Scene to cancel a flight
    public void cancelInternationalFlight() {
        Stage stage = new Stage();
        stage.setTitle("Cancel Flight");

        TextField flightNoField = new TextField();
        Button submitButton = new Button("Cancel Flight");

        GridPane layout = new GridPane();
        layout.setPadding(new Insets(10));
        layout.setVgap(10);
        layout.add(new Label("Flight No:"), 0, 0);
        layout.add(flightNoField, 1, 0);
        layout.add(submitButton, 1, 1);

        submitButton.setOnAction(e -> {
            try {
                int flightNo = Integer.parseInt(flightNoField.getText());
                InternationalFlights.cancelFlight(flightNo); // Call method to cancel flight
                stage.close();
                System.out.println("Flight cancelled successfully.");
            } catch (NumberFormatException ex) {
                throw new InvalidEntryException("Invalid flight number.");
            }
        });

        stage.setScene(new Scene(layout, 300, 150));
        stage.show();
    }
    
    public void viewDomesticFlightDetails() {
        Stage stage = new Stage();
        stage.setTitle("Flight Details");

        TextArea flightDetails = new TextArea();
        flightDetails.setEditable(false);

        // Populate flight details
        StringBuilder details = new StringBuilder();
        for(Flight temp : DomesticFlights.flights)
        {
        	details.append(temp.getFlightDetails()).append("\n");
        }
        flightDetails.setText(details.toString());

        stage.setScene(new Scene(flightDetails, 400, 300));
        stage.show();
    }

    // Scene to create a new flight
    public void scheduleDomesticFlight() {
        Stage stage = new Stage();
        stage.setTitle("Schedule Flight");

        // Fields for flight details
        TextField flightNoField = new TextField();
        TextField flightNameField = new TextField();
        TextField departureDateField = new TextField();
        TextField departureTimeField = new TextField();
        TextField originField = new TextField();
        TextField destinationField = new TextField();

        Button submitButton = new Button("Add Flight");

        // Layout setup
        GridPane layout = new GridPane();
        layout.setPadding(new Insets(10));
        layout.setVgap(10);
        layout.add(new Label("Flight No:"), 0, 0);
        layout.add(flightNoField, 1, 0);
        layout.add(new Label("Flight Name:"), 0, 1);
        layout.add(flightNameField, 1, 1);
        layout.add(new Label("Departure Date (YYYY-MM-DD):"), 0, 2);
        layout.add(departureDateField, 1, 2);
        layout.add(new Label("Departure Time (HH:MM):"), 0, 3);
        layout.add(departureTimeField, 1, 3);
        layout.add(new Label("Origin:"), 0, 4);
        layout.add(originField, 1, 4);
        layout.add(new Label("Destination:"), 0, 5);
        layout.add(destinationField, 1, 5);
        layout.add(submitButton, 1, 6);

        submitButton.setOnAction(e -> {
            try {
                int flightNo = Integer.parseInt(flightNoField.getText());
                String flightName = flightNameField.getText();
                LocalDate departureDate = LocalDate.parse(departureDateField.getText());
                LocalTime departureTime = LocalTime.parse(departureTimeField.getText());
                String origin = originField.getText();
                String destination = destinationField.getText();

                Flight flight = new Flight(flightNo, flightName, departureDate, departureTime, origin, destination);
                DomesticFlights.addFlight(flight);
                stage.close();
                System.out.println("Flight scheduled successfully.");
            } catch (Exception ex) {
                System.out.println("Invalid input. Please enter valid details.");
            }
        });

        stage.setScene(new Scene(layout, 400, 300));
        stage.show();
    }

    // Scene to reschedule an existing flight
    public void rescheduleDomesticFlight() {
        Stage stage = new Stage();
        stage.setTitle("Reschedule Flight");

        TextField flightNoField = new TextField();
        TextField newTimeField = new TextField();
        Button submitButton = new Button("Reschedule");

        GridPane layout = new GridPane();
        layout.setPadding(new Insets(10));
        layout.setVgap(10);
        layout.add(new Label("Flight No:"), 0, 0);
        layout.add(flightNoField, 1, 0);
        layout.add(new Label("New Departure Time (HH:MM):"), 0, 1);
        layout.add(newTimeField, 1, 1);
        layout.add(submitButton, 1, 2);

        submitButton.setOnAction(e -> {
            try {
                int flightNo = Integer.parseInt(flightNoField.getText());
                @SuppressWarnings("unused")
				LocalTime newTime = LocalTime.parse(newTimeField.getText());

                DomesticFlights.editFlight(flightNo); // Call method to edit flight time
                stage.close();
                System.out.println("Flight rescheduled successfully.");
            } catch (NumberFormatException ex) {
                throw new InvalidEntryException("Invalid flight number or time format.");
            }
        });

        stage.setScene(new Scene(layout, 300, 200));
        stage.show();
    }

    // Scene to cancel a flight
    public void cancelDomesticFlight() {
        Stage stage = new Stage();
        stage.setTitle("Cancel Flight");

        TextField flightNoField = new TextField();
        Button submitButton = new Button("Cancel Flight");

        GridPane layout = new GridPane();
        layout.setPadding(new Insets(10));
        layout.setVgap(10);
        layout.add(new Label("Flight No:"), 0, 0);
        layout.add(flightNoField, 1, 0);
        layout.add(submitButton, 1, 1);

        submitButton.setOnAction(e -> {
            try {
                int flightNo = Integer.parseInt(flightNoField.getText());
                DomesticFlights.cancelFlight(flightNo); // Call method to cancel flight
                stage.close();
                System.out.println("Flight cancelled successfully.");
            } catch (NumberFormatException ex) {
                throw new InvalidEntryException("Invalid flight number.");
            }
        });

        stage.setScene(new Scene(layout, 300, 150));
        stage.show();
    }
    
    public void generateDomesticFilghtsReport()
    {
    	@SuppressWarnings("unused")
		DomesticFlightsReport dfr = new DomesticFlightsReport();
    }
    
    public void generateInternationalFilghtsReport()
    {
    	@SuppressWarnings("unused")
		InternationalFlightsReport ifr = new InternationalFlightsReport();
    }
}

