package users;

import data.DomesticFlights;
import data.InternationalFlights;
import exceptions.InvalidEntryException;
import exceptions.SeatsNotAvailableException;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import models.Flight;
import services.Booking;

public class User {

	// Displays the user menu with options to view and book flights
    public void displayMenu() {
        
            Stage stage = new Stage();
            stage.setTitle("User Menu");

            // Buttons for menu options
            Button viewInternationalFlightsButton = new Button("View International Flights");
            Button bookInternationalFlightsButton = new Button("Book International Flight");
            Button viewDomesticFlightsButton = new Button("View Domestic Flights");
            Button bookDomesticFlightsButton = new Button("Book Domestic Flight");

            // Event handlers
            viewInternationalFlightsButton.setOnAction(e -> viewInternationalFlights());
            bookInternationalFlightsButton.setOnAction(e -> bookInternationalFlight());
            viewDomesticFlightsButton.setOnAction(e -> viewDomesticFlights());
            bookDomesticFlightsButton.setOnAction(e -> bookDomesticFlight());

            // Layout
            GridPane gridPane = new GridPane(10, 10);
            gridPane.add(viewInternationalFlightsButton, 1, 1);
            gridPane.add(viewDomesticFlightsButton, 1, 2);
            gridPane.add(bookInternationalFlightsButton, 3, 1);
            gridPane.add(bookDomesticFlightsButton, 3, 2);

            Scene scene = new Scene(gridPane, 400, 200);
            stage.setScene(scene);
            stage.show();
        
    }

    // View flights option, which displays a list of flights in a new window
    public void viewInternationalFlights() {
        Stage stage = new Stage();
        stage.setTitle("Available Flights");

        TextArea flightDetails = new TextArea();
        flightDetails.setEditable(false);

        // Populate flight details
        StringBuilder details = new StringBuilder();
        for(Flight temp : InternationalFlights.flights)
        {
        	details.append(temp.getFlightDetails()).append("\n");
        }
        flightDetails.setText(details.toString());

        stage.setScene(new Scene(new VBox(flightDetails), 400, 300));
        stage.show();
    }

    // Synchronized method to handle flight booking
    public void bookInternationalFlight() {
        Stage bookingStage = new Stage();
        bookingStage.setTitle("Book Flight");

        // Fields for user to enter flight booking details
        TextField flightNoField = new TextField();
        Label infoLabel = new Label("Enter Flight Number to Book:");

        Button bookButton = new Button("Proceed to Booking");

        VBox layout = new VBox(10);
        layout.getChildren().addAll(infoLabel, flightNoField, bookButton);

        // Event handler for booking
        bookButton.setOnAction(e -> {
            try {
                int flightNo = Integer.parseInt(flightNoField.getText());

                // Check if flight exists and proceed with booking
                Flight selectedFlight = InternationalFlights.findFlightByNumber(flightNo);
                if (selectedFlight != null) {
                    Booking booking = new Booking(true);
                    booking.bookTicket(selectedFlight); // Call the Booking class to handle ticket booking
                    bookingStage.close();
                } else {
                    showError("Flight not found. Please check the flight number.");
                }
            } catch (NumberFormatException ex) {
                showError("Invalid flight number. Please enter a valid number.");
            } catch (InvalidEntryException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (SeatsNotAvailableException e1) {
				// TODO Auto-generated catch block
				showError("No seats are available. Please try another flight!");
				e1.printStackTrace();
			}
        });

        bookingStage.setScene(new Scene(layout, 300, 150));
        bookingStage.show();
    }
    
    // View flights option, which displays a list of flights in a new window
    public void viewDomesticFlights() {
        Stage stage = new Stage();
        stage.setTitle("Available Flights");

        TextArea flightDetails = new TextArea();
        flightDetails.setEditable(false);

        // Populate flight details
        StringBuilder details = new StringBuilder();
        for(Flight temp : DomesticFlights.flights)
        {
        	details.append(temp.getFlightDetails()).append("\n");
        }
        flightDetails.setText(details.toString());

        stage.setScene(new Scene(new VBox(flightDetails), 400, 300));
        stage.show();
    }

    // Synchronized method to handle flight booking
    public synchronized void bookDomesticFlight() {
        Stage bookingStage = new Stage();
        bookingStage.setTitle("Book Flight");

        // Fields for user to enter flight booking details
        TextField flightNoField = new TextField();
        Label infoLabel = new Label("Enter Flight Number to Book:");

        Button bookButton = new Button("Proceed to Booking");

        VBox layout = new VBox(10);
        layout.getChildren().addAll(infoLabel, flightNoField, bookButton);

        // Event handler for booking
        bookButton.setOnAction(e -> {
            try {
                int flightNo = Integer.parseInt(flightNoField.getText());

                // Check if flight exists and proceed with booking
                Flight selectedFlight = DomesticFlights.findFlightByNumber(flightNo);
                if (selectedFlight != null) {
                    Booking booking = new Booking(false);
                    booking.bookTicket(selectedFlight); // Call the Booking class to handle ticket booking
                    bookingStage.close();
                } else {
                    showError("Flight not found. Please check the flight number.");
                }
            } catch (NumberFormatException ex) {
                showError("Invalid flight number. Please enter a valid number.");
            } catch (InvalidEntryException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (SeatsNotAvailableException e1) {
				// TODO Auto-generated catch block
				showError("No seats are available. Please try another flight!");
				e1.printStackTrace();
			}
        });

        bookingStage.setScene(new Scene(layout, 300, 150));
        bookingStage.show();
    }

    // Helper method to display error messages
    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
